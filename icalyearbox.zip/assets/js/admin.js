/**
 * Plugin Recursive Shortcode admin js.
 *
 *  @package WordPress Plugin Recursive Shortcode
 */

jQuery( document ).ready(
	function ( e ) {

	}
);
