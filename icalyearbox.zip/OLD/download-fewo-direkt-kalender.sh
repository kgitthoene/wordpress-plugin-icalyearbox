#!/bin/sh
wget 'http://www.fewo-direkt.de/icalendar/29aeb41e2e3e4a0690a89d8e8d8f6a26.ics' -O fewo-direkt.ics
