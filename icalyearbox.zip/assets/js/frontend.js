/**
 * Plugin Recursive Shortcode frontend js.
 *
 *  @package WordPress Plugin Recursive Shortcode
 */

jQuery( document ).ready(
	function ( e ) {

	}
);
