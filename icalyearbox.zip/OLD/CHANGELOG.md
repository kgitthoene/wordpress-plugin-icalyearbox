# Change Log

All notable changes to this project will be documented in this file.

#### Released

* Sanitize fields / v1.0.1 / 20200812
* Initial release / v1.0.0 / 20200810
