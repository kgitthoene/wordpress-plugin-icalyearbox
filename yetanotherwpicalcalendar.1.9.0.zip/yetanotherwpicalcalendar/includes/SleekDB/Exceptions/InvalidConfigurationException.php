<?php

namespace SleekDB\Exceptions;

class InvalidConfigurationException extends \Exception
{
}
