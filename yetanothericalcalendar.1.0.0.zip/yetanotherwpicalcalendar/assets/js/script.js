/**
 * Wordpress Plugin YetAnotherWPICALCalendar (Javascript Component)
 *
 * @license MIT https://en.wikipedia.org/wiki/MIT_License
 * @author  Kai Thoene <k.git.thoene@gmx.net>
 */
if (window.jQuery) {
  globalThis[Symbol.for('yetanotherwpicalcalendar_storage')] = (function () {
    var defaults = {
      'debug': false, // false = no debug on console
      'is_enabled': true,
      'token': 'yetanotherwpicalcalendar'
    };
    var resize_timeout = null;

    function is_empty(s = '') {
      return (!s || s.length === 0);
    } // is_empty

    function is_null(v = null) {
      return (v == null);
    } // is_null

    function resize() {
      try {
        html5tooltips.refresh();
      }
      catch (e) { console.error("plugin:" + _g.defaults.token + ":EXCEPTION: " + e); }
    }  // resize

    /**
     * sends a request to the specified url from a form. this will change the window location.
     * @param {string} path the path to send the post request to
     * @param {object} params the parameters to add to the url
     * @param {string} [method=post] the method to use on the form
     */
    function _post(path, params, method = 'post') {
      // The rest of this code assumes you are not using a library.
      // It can be made less verbose if you use one.
      const form = document.createElement('form');
      form.method = method;
      form.action = path;
      for (const key in params) {
        if (params.hasOwnProperty(key)) {
          const hiddenField = document.createElement('input');
          hiddenField.type = 'hidden';
          hiddenField.name = key;
          hiddenField.value = params[key];
          form.appendChild(hiddenField);
        }
      }
      document.body.appendChild(form);
      form.submit();
    }

    function post_cb(jqXHR, status, data = {}, error_thrown = '') {
      console.log("[POST-CB] STATUS='" + status + "' DATA='" + JSON.stringify(data) + " ERROR-THROWN='" + error_thrown + "'");
    } // post_cb

    function post_cb_success(data, status, jqXHR) {
      post_cb(jqXHR, status, data);
    }  // post_cb_success

    function post_cb_error(jqXHR, status, error_thrown) {
      post_cb(jqXHR, status, {}, error_thrown);
    }  // post_cb_error

    function post(uri, object, cb_success = null, cb_error = null) {
      jQuery(function ($) {
        return $.ajax({
          url: uri,
          data: object,
          method: 'POST',
          success: (is_null(cb_success) ? post_cb_success : cb_success),
          error: (is_null(cb_error) ? post_cb_error : cb_error),
        });
      });
    }  // post

    function annotate(id = '', day = '') {
      console.log(defaults.token + "::annotate ID='" + id + "' DAY='" + day + "'");
      jQuery(function ($) {
        _ga = globalThis[Symbol.for('yetanotherwpicalcalendar_annotation_storage')];
        console.log("GA ->:");
        console.log(_ga);
        modal = _ga.modals[id];
        _ga.data[id] = { day: day };
        _ga.post_state[id] = null;
        modal.open();
        setTimeout(function () {
          console.log("FOCUS");
          $("#" + id + "-fname").focus();
        }, 100);
        let resultInterval = setInterval(function () {
          if ((_ga.post_state[id] != null) && (_ga.post_state[id] != 0)) {
            $("#" + id + "-cal-msg").text(_ga.post_state[id]);
            $("#" + id + "-cal-msg").css('display', 'block');
            clearInterval(resultInterval);
          }
        }, 100);
      });
    } // annotate

    return {
      // exported variables:
      defaults: defaults,
      resize_timeout: resize_timeout,
      // exported functions:
      is_empty: is_empty,
      is_null: is_null,
      resize: resize,
      post_cb: post_cb,
      post: post,
      annotate: annotate,
    };
  })();

  addEventListener("DOMContentLoaded", (event) => {
    (function ($) {
      var _g = globalThis[Symbol.for('yetanotherwpicalcalendar_storage')];
      if (_g.defaults.is_enabled) {

        yetanotherwpicalcalendar_annotate = _g.annotate;

        $(window).resize(function () {
          if (_g.resize_timeout != null) { clearTimeout(_g.resize_timeout); }
          _g.resize_timeout = setTimeout(_g.resize, 100);
        });

        _g.resize();

        //
        //----------
        // Search for annotations:
        function cb_get_annotations_success(data, status, jqXHR) {
          _g.post_cb(jqXHR, status, data);
          console.log("jqXHR.data='" + JSON.stringify(jqXHR.data) + "'");
          console.log(jqXHR);
        }
        function cb_get_annotations_error(jqXHR, status, error_thrown) {
          _g.post_cb(jqXHR, status, {}, error_thrown);
          console.log("jqXHR.data='" + JSON.stringify(jqXHR.data) + "'");
          console.log(jqXHR);
        }
        $(".yetanotherwpicalcalendar-annotation").each(function (idx) {
          let id = $(this).attr('id');
          if (_g.is_empty(id)) {
            $(this).html('<div style="border-left:4px solid red;">&nbsp;No ID for annotations given!</div>');
          } else {
            let obj = { action: 'yetanotherwpicalcalendar_get_annotations', id: id };
            $.ajax({
              url: '/wp-admin/admin-ajax.php',
              data: obj,
              method: 'POST'
            })
              .done(function (data, status, jqXHR) {
                //_g.post_cb(jqXHR, status, data);
                //console.log("[DONE] ID='" + $(this).attr('id') + "'");
                var b_is_ok = false;
                if (status == 'success') {
                  let rc = data['status'];
                  b_is_ok = (rc == 'OK');
                }
                if (b_is_ok) {
                  let id = data['id'];
                  let a_an = data['annotations'];
                  if (a_an.length == 0) {
                    $(this).html(data['msg']);
                  }
                }
              }.bind(this))
              .fail(function (jqXHR, status, error_thrown) {
                let id = $(this).attr('id');
                $(this).html('<div style="unicode-bidi:embed; font-family:monospace; font-size:12px; font-weight:normal; color:black; background-color:#FFAA4D; border-left:12px solid red; padding:3px 6px 3px 6px;">'
                  + 'Plugin YetAnotherWPICALCalendar::ERROR -- Cannot get annotations! STATUS="' + status + '" ERROR="' + error_thrown
                  + '<br />[yetanotherwpicalcalendar-annotation id="' + id + '"]'
                  + '"</div>');
              }.bind(this));
          }
        });
        //
      }
    })(jQuery);
  });
} else {
  console.error("plugin:yetanotherwpicalcalendar:ERROR: jQuery is undefined!");
}
